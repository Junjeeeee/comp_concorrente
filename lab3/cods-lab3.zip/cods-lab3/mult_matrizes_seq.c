#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include "timer.h"

// descomentar o define abaixo caso deseje imprimir uma versão truncada da matriz gerada no formato texto
#define TEXTO 

// Variáveis globais
float *matriz1; // matriz de entrada 1
float *matriz2; // matriz de entrada 2
float *matriz_saida; // matriz de saída
int num_threads; // número de threads

// Fluxo principal
int main(int argc, char* argv[]) {
   int linhas_matriz1, colunas_matriz1; // dimensões da matriz1
   int linhas_matriz2, colunas_matriz2; // dimensões da matriz2
   long long int tamanho_matriz1, tamanho_matriz2;

   FILE *arquivo_matriz1; // descritor do arquivo de entrada para matriz1
   size_t leitura_matriz1; // retorno da função de leitura da matriz1
   FILE *arquivo_matriz2; // descritor do arquivo de entrada para matriz2
   size_t leitura_matriz2; // retorno da função de leitura da matriz2
   FILE *arquivo_saida; // descritor do arquivo de saída
   size_t escrita_saida; // retorno da função de escrita da matriz de saída

   double inicio, fim, tempo_execucao;
   
   GET_TIME(inicio);
   // Verificação e leitura dos parâmetros de entrada
   if(argc < 4) {
      fprintf(stderr, "Uso: %s <arquivo entrada 1> <arquivo entrada 2>  <arquivo saida>\n", argv[0]);
      return 1;
   }
   
   arquivo_matriz1 = fopen(argv[1], "rb");
   if(!arquivo_matriz1) {
      fprintf(stderr, "Erro ao abrir o arquivo 1\n");
      return 2;
   }

   // Leitura das dimensões da matriz1
   leitura_matriz1 = fread(&linhas_matriz1, sizeof(int), 1, arquivo_matriz1);
   if(!leitura_matriz1) {
      fprintf(stderr, "Erro ao ler as dimensões da matriz 1\n");
      return 3;
   }
   leitura_matriz1 = fread(&colunas_matriz1, sizeof(int), 1, arquivo_matriz1);
   if(!leitura_matriz1) {
      fprintf(stderr, "Erro ao ler as dimensões da matriz 1\n");
      return 3;
   }

   tamanho_matriz1 = linhas_matriz1 * colunas_matriz1;

   // Alocação de memória para matriz1
   matriz1 = (float*) malloc(sizeof(float) * tamanho_matriz1);
   if(!matriz1) {
      fprintf(stderr, "Erro ao alocar memória para matriz 1\n");
      return 3;
   }

   // Carregamento da matriz1 do arquivo
   leitura_matriz1 = fread(matriz1, sizeof(float), tamanho_matriz1, arquivo_matriz1);
   if(leitura_matriz1 < tamanho_matriz1) {
      fprintf(stderr, "Erro ao ler os elementos da matriz 1\n");
      return 4;
   }

   arquivo_matriz2 = fopen(argv[2], "rb");
   if(!arquivo_matriz2) {
      fprintf(stderr, "Erro ao abrir o arquivo 2\n");
      return 2;
   }

   // Leitura das dimensões da matriz2
   leitura_matriz2 = fread(&linhas_matriz2, sizeof(int), 1, arquivo_matriz2);
   if(!leitura_matriz2) {
      fprintf(stderr, "Erro ao ler as dimensões da matriz 2\n");
      return 3;
   }
   leitura_matriz2 = fread(&colunas_matriz2, sizeof(int), 1, arquivo_matriz2);
   if(!leitura_matriz2) {
      fprintf(stderr, "Erro ao ler as dimensões da matriz 2\n");
      return 3;
   }

   tamanho_matriz2 = linhas_matriz2 * colunas_matriz2;

   // Alocação de memória para matriz2
   matriz2 = (float*) malloc(sizeof(float) * tamanho_matriz2);
   if(!matriz2) {
      fprintf(stderr, "Erro ao alocar memória para matriz 2\n");
      return 3;
   }

   // Carregamento da matriz2 do arquivo
   leitura_matriz2 = fread(matriz2, sizeof(float), tamanho_matriz2, arquivo_matriz2);
   if(leitura_matriz2 < tamanho_matriz2) {
      fprintf(stderr, "Erro ao ler os elementos da matriz 2\n");
      return 4;
   }

   // Verifica se as dimensões das matrizes são compatíveis
   if(colunas_matriz1 != linhas_matriz2) {
      fprintf(stderr, "Dimensões não compatíveis!\n");
      return 5;
   }

   long long int dimensao_matriz_saida = (colunas_matriz2 * linhas_matriz1);  // dimensões da matriz resultante

   // Alocação de memória para a matriz de saída
   matriz_saida = (float *) malloc(sizeof(float) * dimensao_matriz_saida);
   if (matriz_saida == NULL) {
       printf("Erro ao alocar memória para matriz de saída\n");
       return 2;
   }

   GET_TIME(fim);

   tempo_execucao = fim - inicio;
   printf("Tempo de inicialização: %lf\n", tempo_execucao);

   // Multiplicação das matrizes
   GET_TIME(inicio);
   

   for(int i = 0; i < linhas_matriz1; i++) {
    for(int j = 0; j < colunas_matriz2; j++) {
        matriz_saida[i * colunas_matriz2 + j] = 0;  // Inicializa o valor de saída
        for(int k = 0; k < colunas_matriz1; k++) {
            matriz_saida[i * colunas_matriz2 + j] += matriz1[i * colunas_matriz1 + k] * matriz2[k * colunas_matriz2 + j];
        }
    }
}


   GET_TIME(fim);
   tempo_execucao = fim - inicio;
   printf("Tempo de multiplicação (dimensão %lld) (nthreads %d): %lf\n", dimensao_matriz_saida, num_threads, tempo_execucao);

   // Impressão da matriz resultante
   int linhas_saida = linhas_matriz1;
   int colunas_saida = colunas_matriz2;

   #ifdef TEXTO
   for(int i = 0; i < linhas_saida; i++) {
      for(int j = 0; j < colunas_saida; j++)
        fprintf(stdout, "%.6f ", matriz_saida[i * colunas_saida + j]);
      fprintf(stdout, "\n");
   }
   #endif

   // Escrita da matriz no arquivo de saída
   arquivo_saida = fopen(argv[3], "wb");
   if(!arquivo_saida) {
      fprintf(stderr, "Erro ao abrir o arquivo de saída\n");
      return 3;
   }
   // Escreve o número de linhas e colunas
   escrita_saida = fwrite(&linhas_saida, sizeof(int), 1, arquivo_saida);
   escrita_saida = fwrite(&colunas_saida, sizeof(int), 1, arquivo_saida);
   // Escreve os elementos da matriz
   escrita_saida = fwrite(matriz_saida, sizeof(float), dimensao_matriz_saida, arquivo_saida);
   if(escrita_saida < dimensao_matriz_saida) {
      fprintf(stderr, "Erro ao escrever no arquivo de saída\n");
      return 4;
   }

   // Finaliza o uso das variáveis
   fclose(arquivo_saida);

   // Liberação da memória
   GET_TIME(inicio);
   free(matriz1);
   free(matriz2);
   free(matriz_saida);

   GET_TIME(fim);   
   tempo_execucao = fim - inicio;
   printf("Tempo de finalização: %lf\n", tempo_execucao);

   return 0;
}